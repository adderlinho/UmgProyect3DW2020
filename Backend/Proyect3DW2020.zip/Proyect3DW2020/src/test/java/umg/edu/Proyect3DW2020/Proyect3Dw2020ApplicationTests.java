package umg.edu.Proyect3DW2020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyect3Dw2020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
