package umg.edu.Proyect3DW2020;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyect3Dw2020Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyect3Dw2020Application.class, args);
	}

}
